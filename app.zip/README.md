:warning: *Use of this software is subject to important terms and conditions as set forth in the License file* :warning:

# Private Comment App

## Description:

An app which uses the below endpoints:

* /api/v2/{{ticket_id}}/.json

The app is designed to create a way for Zendesk agents easily add private comment to a ticket while also typing a public comment.

## App location:

* Ticket sidebar

## Features:

* Make private comment

## Set-up/installation instructions:

Install and activate the app, then open a ticket.
